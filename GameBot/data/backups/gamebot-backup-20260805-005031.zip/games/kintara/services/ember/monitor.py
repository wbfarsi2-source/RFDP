from __future__ import annotations

import gzip
import json
import logging
import random
import re
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable

import httpx
import websocket

from core.system_proxy import websocket_proxy_options
from core.worker_protocol import WorkerEventType

logger = logging.getLogger(__name__)

EMBER_REGION = "ember"
REGISTER_EVERY_SECONDS = 5.0
SOCKET_TIMEOUT_SECONDS = 2.0
STALE_AFTER_SECONDS = 15.0
REFRESH_SERVERS_SECONDS = 60.0
SUMMARY_SECONDS = 20.0
MINIMUM_ACCURATE_COVERAGE = 0.95
SERVER_RETRY_MIN_SECONDS = 5.0
SERVER_RETRY_MAX_SECONDS = 120.0
MONITOR_IDLE_SECONDS = 1.0


class MonitorAuthenticationError(RuntimeError):
    pass


def _server_number(server: dict[str, Any]) -> int:
    match = re.fullmatch(r"Server\s+(\d+)", str(server.get("name") or ""))
    return int(match.group(1)) if match else -1


def _route_shard_id(server: dict[str, Any]) -> int:
    for key in ("routeShardId", "localShardId", "id"):
        try:
            value = int(float(server.get(key) or 0))
        except Exception:
            value = 0
        if value > 0:
            return value
    return 0


def _ws_url(server: dict[str, Any]) -> str:
    shard = _route_shard_id(server)
    if shard <= 0:
        raise RuntimeError("Invalid spectator shard")
    base = str(server.get("wsBaseUrl") or "").strip()
    if base:
        if base.startswith(("ws://", "wss://")):
            return base.rstrip("/") + f"/ws/spectate/s{shard}"
        return re.sub(r"^http", "ws", base, flags=re.I).rstrip("/") + f"/ws/spectate/s{shard}"
    return f"wss://kintara.gg/ws/spectate/s{shard}"


def _decode_frames(raw: Any) -> list[dict[str, Any]]:
    try:
        if isinstance(raw, (bytes, bytearray)):
            data = bytes(raw)
            if data and data[0] == 1:
                data = gzip.decompress(data[1:])
            text = data.decode("utf-8", errors="replace")
        else:
            text = str(raw)
        payload = json.loads(text)
    except Exception:
        return []
    if isinstance(payload, dict):
        return [payload]
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    return []


def _is_human(player: Any) -> bool:
    if not isinstance(player, dict):
        return False
    try:
        if int(float(player.get("id"))) <= 0:
            return False
    except Exception:
        return False
    if any(bool(player.get(key)) for key in ("isNpc", "isNPC", "npc", "isMob", "isBoss", "isPet")):
        return False
    marker = " ".join(
        str(player.get(key) or "").strip().lower()
        for key in ("type", "kind", "entityType", "entity_type", "npcType", "mobType", "species")
    )
    blocked = (
        "npc",
        "mob",
        "boss",
        "enemy",
        "monster",
        "creature",
        "spider",
        "pet",
        "companion",
        "minion",
        "summon",
        "animal",
    )
    return not any(word in marker for word in blocked)


@dataclass
class WatcherState:
    server: str
    number: int
    connected: bool
    live: bool
    count: int
    snapshots: int
    age: float | None
    error: str


class EmberSpectatorWatcher:
    """Low-overhead anonymous Molten spectator for one numbered server."""

    def __init__(self, server: dict[str, Any], user_agent: str) -> None:
        self.server = dict(server)
        self.user_agent = user_agent
        self.name = str(server.get("name") or "?")
        self.number = _server_number(server)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.connected = False
        self.player_count = 0
        self.snapshots = 0
        self.last_snapshot_at = 0.0
        self.error = ""
        self.ws = None
        self.thread = threading.Thread(target=self._run, name=f"molten-{self.number}", daemon=True)

    @property
    def endpoint(self) -> str:
        return _ws_url(self.server)

    def start(self) -> "EmberSpectatorWatcher":
        self.thread.start()
        return self

    def stop(self) -> None:
        self.stop_event.set()
        try:
            if self.ws is not None:
                self.ws.close()
        except Exception:
            pass

    def state(self) -> WatcherState:
        with self.lock:
            age = None if self.last_snapshot_at <= 0 else time.time() - self.last_snapshot_at
            return WatcherState(
                server=self.name,
                number=self.number,
                connected=bool(self.connected),
                live=bool(age is not None and age <= STALE_AFTER_SECONDS),
                count=int(self.player_count),
                snapshots=int(self.snapshots),
                age=age,
                error=str(self.error or ""),
            )

    def _connect(self):
        url = self.endpoint
        return websocket.create_connection(
            url,
            timeout=20,
            origin="https://kintara.gg",
            enable_multithread=True,
            header=[
                f"User-Agent: {self.user_agent}",
                "Pragma: no-cache",
                "Cache-Control: no-cache",
            ],
            **websocket_proxy_options(url),
        )

    def _run(self) -> None:
        retry = 2.0
        while not self.stop_event.is_set():
            received_snapshot = False
            try:
                self.ws = self._connect()
                self.ws.settimeout(SOCKET_TIMEOUT_SECONDS)
                with self.lock:
                    self.connected = True
                    self.error = ""
                last_register = 0.0
                while not self.stop_event.is_set():
                    now = time.monotonic()
                    if now - last_register >= REGISTER_EVERY_SECONDS:
                        self.ws.send(
                            json.dumps(
                                {"t": "spec_reg", "region": EMBER_REGION},
                                separators=(",", ":"),
                            )
                        )
                        last_register = now
                    try:
                        raw = self.ws.recv()
                    except websocket.WebSocketTimeoutException:
                        continue
                    if raw in (None, ""):
                        raise RuntimeError("spectator socket closed")
                    for message in _decode_frames(raw):
                        if str(message.get("t") or "") != "snap":
                            continue
                        if str(message.get("region") or "").strip().lower() != EMBER_REGION:
                            continue
                        count = sum(1 for player in (message.get("players") or []) if _is_human(player))
                        with self.lock:
                            self.player_count = count
                            self.snapshots += 1
                            self.last_snapshot_at = time.time()
                            self.error = ""
                        received_snapshot = True
                        retry = 2.0
            except Exception as exc:
                with self.lock:
                    self.connected = False
                    self.error = str(exc)[:180]
            finally:
                try:
                    if self.ws is not None:
                        self.ws.close()
                except Exception:
                    pass
                self.ws = None
                with self.lock:
                    self.connected = False
            if not self.stop_event.is_set():
                if not received_snapshot:
                    retry = min(60.0, retry * 1.7)
                self.stop_event.wait(retry + random.uniform(0.0, 0.8))


class KintaraEmberMonitor:
    def __init__(
        self,
        *,
        base_url: str,
        cookie: str,
        user_agent: str,
        cookie_provider: Callable[[], str] | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.cookie = cookie
        self.user_agent = user_agent
        self.cookie_provider = cookie_provider
        self.watchers: dict[int, EmberSpectatorWatcher] = {}
        self._http_client: httpx.Client | None = None
        self._last_server_error = ""

    def _resolve_cookie(self) -> str:
        if self.cookie_provider is not None:
            try:
                latest = str(self.cookie_provider() or "").strip()
                if latest:
                    self.cookie = latest
            except Exception:
                pass
        return self.cookie

    def _client(self) -> httpx.Client:
        cookie = self._resolve_cookie()
        if self._http_client is None:
            self._http_client = httpx.Client(
                timeout=httpx.Timeout(20.0, connect=15.0),
                headers={
                    "User-Agent": self.user_agent,
                    "Accept": "application/json,text/plain,*/*",
                    "Origin": self.base_url,
                    "Referer": self.base_url + "/play",
                    "Cookie": cookie,
                },
                trust_env=True,
            )
        else:
            self._http_client.headers["Cookie"] = cookie
        return self._http_client

    def _fetch_servers(self) -> list[dict[str, Any]]:
        response = self._client().get(self.base_url + "/api/servers")
        if response.status_code in (401, 403):
            raise MonitorAuthenticationError("The shared Kintara session is no longer valid")
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict) or payload.get("ok") is False:
            raise RuntimeError("Kintara server list is unavailable")
        rows = [
            dict(row)
            for row in (payload.get("servers") or [])
            if isinstance(row, dict) and _server_number(row) >= 1
        ]
        rows.sort(key=_server_number)
        if not rows:
            raise RuntimeError("Kintara returned no numbered servers")
        return rows

    def _replace_watcher(self, number: int, server: dict[str, Any]) -> None:
        previous = self.watchers.pop(number, None)
        if previous is not None:
            previous.stop()
            try:
                previous.thread.join(timeout=2.0)
            except Exception:
                pass
        self.watchers[number] = EmberSpectatorWatcher(server, self.user_agent).start()

    def _sync_watchers(self) -> None:
        servers = self._fetch_servers()
        current = {_server_number(row): row for row in servers}
        for number in list(self.watchers):
            if number not in current:
                watcher = self.watchers.pop(number)
                watcher.stop()
        for number, server in current.items():
            existing = self.watchers.get(number)
            if existing is None:
                self.watchers[number] = EmberSpectatorWatcher(server, self.user_agent).start()
                time.sleep(0.02)
                continue
            try:
                endpoint_changed = existing.endpoint != _ws_url(server)
            except Exception:
                endpoint_changed = True
            if endpoint_changed:
                self._replace_watcher(number, server)
            else:
                existing.server = dict(server)
        self._last_server_error = ""

    def stop(self) -> None:
        for watcher in list(self.watchers.values()):
            watcher.stop()
        for watcher in list(self.watchers.values()):
            try:
                watcher.thread.join(timeout=2.5)
            except Exception:
                pass
        self.watchers.clear()
        if self._http_client is not None:
            try:
                self._http_client.close()
            except Exception:
                pass
            self._http_client = None

    def _summary_payload(self) -> dict[str, Any]:
        states = [watcher.state() for watcher in self.watchers.values()]
        ready = [
            row
            for row in states
            if row.live and row.snapshots >= 2 and row.age is not None and row.age <= STALE_AFTER_SECONDS
        ]
        coverage = (len(ready) / len(states)) if states else 0.0
        top = sorted(
            [row for row in ready if row.count > 0],
            key=lambda row: (-row.count, row.number),
        )[:3]
        return {
            "monitored": len(states),
            "live": len(ready),
            "coverage": coverage,
            "accurate": bool(states and coverage >= MINIMUM_ACCURATE_COVERAGE),
            "total_players": sum(row.count for row in ready),
            "top3": [{"server": row.server, "count": row.count} for row in top],
        }

    def run(
        self,
        stop_event,
        emit: Callable[..., None],
        *,
        summary_seconds: float = SUMMARY_SECONDS,
        server_refresh_seconds: float = REFRESH_SERVERS_SECONDS,
        refresh_requested: Callable[[], bool] | None = None,
    ) -> None:
        summary_seconds = max(20.0, float(summary_seconds or SUMMARY_SECONDS))
        server_refresh_seconds = max(60.0, float(server_refresh_seconds or REFRESH_SERVERS_SECONDS))
        next_server_refresh_at = 0.0
        next_summary_at = 0.0
        force_deadline = 0.0
        retry_seconds = SERVER_RETRY_MIN_SECONDS

        try:
            while not stop_event.is_set():
                now = time.monotonic()

                if now >= next_server_refresh_at:
                    try:
                        self._sync_watchers()
                        retry_seconds = SERVER_RETRY_MIN_SECONDS
                        next_server_refresh_at = now + server_refresh_seconds
                        if next_summary_at <= 0:
                            next_summary_at = now + 8.0
                    except MonitorAuthenticationError as exc:
                        message = str(exc)
                        if message != self._last_server_error:
                            logger.warning("Molten monitor authentication is unavailable: %s", message)
                            self._last_server_error = message
                        emit(WorkerEventType.ERROR, message, recoverable=True, retry_seconds=60)
                        next_server_refresh_at = now + 60.0
                    except Exception as exc:
                        message = str(exc)[:240]
                        if message != self._last_server_error:
                            logger.warning("Molten server refresh failed; keeping the current process alive: %s", message)
                            self._last_server_error = message
                        emit(
                            WorkerEventType.ERROR,
                            "Molten server refresh is temporarily unavailable",
                            recoverable=True,
                            retry_seconds=int(retry_seconds),
                        )
                        next_server_refresh_at = now + retry_seconds
                        retry_seconds = min(SERVER_RETRY_MAX_SECONDS, retry_seconds * 1.7)

                if refresh_requested and refresh_requested():
                    force_deadline = now + 12.0
                    next_server_refresh_at = min(next_server_refresh_at, now)

                should_publish = next_summary_at > 0 and now >= next_summary_at
                if force_deadline > 0:
                    should_publish = True

                if should_publish and self.watchers:
                    payload = self._summary_payload()
                    if payload["accurate"]:
                        emit(
                            WorkerEventType.METRIC,
                            "Molten location snapshot",
                            service_key="molten_location",
                            **payload,
                        )
                        next_summary_at = now + summary_seconds
                        force_deadline = 0.0
                    elif force_deadline > 0 and now >= force_deadline:
                        emit(
                            WorkerEventType.STATUS,
                            "Molten data is still being verified",
                            service_key="molten_location",
                            **payload,
                        )
                        force_deadline = 0.0
                        next_summary_at = min(next_summary_at or now + 5.0, now + 5.0)

                stop_event.wait(MONITOR_IDLE_SECONDS)
        finally:
            self.stop()
